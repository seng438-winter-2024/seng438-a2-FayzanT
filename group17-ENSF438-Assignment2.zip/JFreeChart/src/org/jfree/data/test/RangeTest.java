package org.jfree.data.test;

import org.junit.Test;

import java.security.InvalidParameterException;


import static org.junit.Assert.*; import org.jfree.data.Range; import org.junit.*;

public class RangeTest {
    private Range exampleRange;
    @BeforeClass public static void setUpBeforeClass() throws Exception {
    }


    @Before
    public void setUp() throws Exception { exampleRange = new Range(-1, 1);
    }


    @Test
    public void centralValueShouldBeZero() {
        assertEquals("The central value of -1 and 1 should be 0",
        0, exampleRange.getCentralValue(), .000000001d);
    }
    

    @Test
    public void getLowerBound() {

        final double expectedLower = 0.0;
        final double expectedUpper = 10.0;
        Range range = new Range(expectedLower, expectedUpper);

        // Verify that the Range object was constructed with the expected lower and upper bounds
        assertEquals("The expected Lower should be 0.0",expectedLower, range.getLowerBound(), 0.001);
 
    }
    
    @Test
    public void getUpperBound() {

        final double expectedLower = 0.0;
        final double expectedUpper = 0.1;
        Range range = new Range(expectedLower, expectedUpper);
       
        // Verify that the Range object was constructed with the expected lower and upper bounds
        assertEquals("The expected upper should be 20.0",expectedUpper, range.getUpperBound(), 0.001);
 
    }
    
    
    

        @Test
        public void testInvalidValueContains() {
            Range invalidContains = new Range(0.0, 10.0);
            assertEquals("The value (12.0) is not in the set range", false, invalidContains.contains(12.0));
            
            Range validContains = new Range(0.0, 10.0);
            assertEquals("The value (5.0) is not in the set range", true, validContains.contains(5.0));


           
        }
    
        
         @Test
         public void testGetLength() {
                Range range1 = new Range(0.0, 10.0);
                assertEquals("The length of the range should be 10.0", 10.0, range1.getLength(), 0.001);

                Range range2 = new Range(-5.0, 5.0);
                assertEquals("The length of the range should be 10.0", 10.0, range2.getLength(), 0.001);


               
            }
         
         @Test
         public void testShiftPositiveToNegative() {
             // Test case 1: Shift right by delta, without allowing zero crossing
             Range base1 = new Range(-5.0, 5.0);
             Range shifted1 = Range.shift(base1, -7.0, false);
             assertEquals("The lower bound should be -12.0", -12.0, shifted1.getLowerBound(), 0.001);
             assertEquals("The new range should be 0", 0.0, shifted1.getLowerBound() + shifted1.getLength(), 0.001);
             
             Range base2 = new Range(-5.0, 5.0);
             Range shifted2 = Range.shift(base2, -7.0, true);
             assertEquals("The lower bound should be -12.0", -12.0, shifted2.getLowerBound(), 0.001);
             assertEquals("The new range should be -2.0", -2.0, shifted2.getLowerBound() + shifted2.getLength(), 0.001);
         }
       

         @Test(expected = InvalidParameterException.class)
         public void testShiftNullBase() {
             Range.shift(null, 5.0, true);
         }
         
      
        
         


}