package org.jfree.data.test;


import static org.junit.Assert.*;
import org.jfree.data.DataUtilities;
import org.jfree.data.Values2D;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Test;
import java.lang.Number;
import org.jfree.data.KeyedValues;

import java.security.InvalidParameterException;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertTrue;

public class DataUtilitiesTest extends DataUtilities {

	
	 
	 @Test
	 public void calculateRowTotal() {
	     // setup
	     Mockery mockingContext = new Mockery();
	     final Values2D values = mockingContext.mock(Values2D.class);
	     mockingContext.checking(new Expectations() {
	         {
	             one(values).getRowCount();
	             will(returnValue(4));
	             one(values).getValue(0, 0);
	             will(returnValue(7.5));
	             one(values).getValue(0, 1);
	             will(returnValue(2.5));
	             one(values).getValue(0, 2);
	             will(returnValue(7.5));
	             one(values).getValue(0, 3);
	             will(returnValue(2.5));
	            
	             
	         }
	     });
	     double result = DataUtilities.calculateRowTotal(values, 0);
	     // verify

	     assertEquals(result, 20, .000000001d);
	     //Change to 20 for actual test since this assert account for this method skipping last parameter
	     // tear-down: NONE in this test method
	 }
	 
	 @Test
	 public void createNumberArray() {
	     // setup
	   
	     double[]  testData = {4.5,5.6};
	     String test = "java.lang.Number[]";
	     Number [] result = DataUtilities.createNumberArray(testData);
	     String resultType = result.getClass().getTypeName();
	     assertNotNull("Result should not be null", result);
	     assertEquals(resultType, test);
	     
	 }


	 
	
	 
	 @Test
	 public void testGetCumulativePercentages() {
		    // Create a mock for KeyedValues
		    Mockery mockingContext = new Mockery();
		    final KeyedValues inputValues = mockingContext.mock(KeyedValues.class);

		    // Set expectations
		    mockingContext.checking(new Expectations() {{
		        allowing(inputValues).getItemCount(); will(returnValue(3));

		        allowing(inputValues).getValue(0); will(returnValue(5)); // Allow multiple calls
		        allowing(inputValues).getValue(1); will(returnValue(9)); // Allow multiple calls
		        allowing(inputValues).getValue(2); will(returnValue(2)); // Allow multiple calls

		        allowing(inputValues).getKey(0); will(returnValue(0)); // Allow multiple calls for key 0
		        allowing(inputValues).getKey(1); will(returnValue(1)); // Allow calls for key 1 as well
		        allowing(inputValues).getKey(2); will(returnValue(2)); // Allow calls for key 1 as well
		        
		    }});

		    // Execute the method under test
		    KeyedValues result = DataUtilities.getCumulativePercentages(inputValues);
		    	    
		    // Assertions to verify the outcome
		    assertNotNull("The result should not be null", result);
		    assertEquals("The cumulative percentage of the first item is incorrect.", 0.3125, result.getValue(0).doubleValue(), 0.0001);
		    assertEquals("The cumulative percentage of the second item is incorrect.", 0.875, result.getValue(1).doubleValue(), 0.0001);
		    assertEquals("The cumulative percentage of the second item is incorrect.", 1.0, result.getValue(2).doubleValue(), 0.0001);


		    // Verify that the expectations were met
		    mockingContext.assertIsSatisfied();
		}
	 @Test
	 public void calculateColumnTotalForTwoValues() {
	     // setup
	     Mockery mockingContext = new Mockery();
	     final Values2D values = mockingContext.mock(Values2D.class);
	     mockingContext.checking(new Expectations() {
	         {
	             one(values).getRowCount();
	             will(returnValue(2));
	             one(values).getValue(0, 0);
	             will(returnValue(7.5));
	             one(values).getValue(1, 0);
	             will(returnValue(2.5));
	         }
	     });
	     double result = DataUtilities.calculateColumnTotal(values, 0);
	     // verify
	      assertEquals(result, 10.0, .000000001d);
	     // tear-down: NONE in this test method
	 }
	 
	 @Test
	 public void testCreateNumberArray2DWithValidInput() {
	        // Setup the input array
	        double[][] input = {
	            {1.1, 2.2, 3.3},
	            {4.4, 5.5, 6.6},
	            {7.7, 8.8, 9.9}
	        };

	        // Expected output (Number[][])
	        Number[][] expected = {
	            {1.1, 2.2, 3.3},
	            {4.4, 5.5, 6.6},
	            {7.7, 8.8, 9.9}
	        };

	        // Call the method under test
	        Number[][] actual = DataUtilities.createNumberArray2D(input);

	        // Assert the result matches the expected output
	        assertNotNull("Result should not be null", actual);
	        assertEquals("Array dimensions should match", expected.length, actual.length);

	        // Check each element
	        for (int i = 0; i < expected.length; i++) {
	            assertArrayEquals("Row " + i + " should match expected values", expected[i], actual[i]);
	        }
	    }
	 
	 @Test
	    public void calculateColumnTotalWithNullValues2DThrowsInvalidParameterException() {
	        try {
	            DataUtilities.calculateColumnTotal(null, 0);
	            fail("Expected an InvalidParameterException to be thrown");
	        } catch (InvalidParameterException e) {
	            assertTrue("Expected InvalidParameterException", true);
	        }
	    }

	    @Test
	    public void calculateRowTotalWithNullValues2DThrowsInvalidParameterException() {
	        try {
	            DataUtilities.calculateRowTotal(null, 0);
	            fail("Expected an InvalidParameterException to be thrown");
	        } catch (InvalidParameterException e) {
	            assertTrue("Expected InvalidParameterException", true);
	        }
	    }

	    @Test
	    public void createNumberArrayWithNullInputThrowsInvalidParameterException() {
	        try {
	            DataUtilities.createNumberArray(null);
	            fail("Expected an InvalidParameterException to be thrown");
	        } catch (InvalidParameterException e) {
	            assertTrue("Expected InvalidParameterException", true);
	        }
	    }

	    @Test
	    public void createNumberArray2DWithNullInputThrowsInvalidParameterException() {
	        try {
	            DataUtilities.createNumberArray2D(null);
	            fail("Expected an InvalidParameterException to be thrown");
	        } catch (InvalidParameterException e) {
	            assertTrue("Expected InvalidParameterException", true);
	        }
	    }

	    @Test
	    public void getCumulativePercentagesWithNullKeyedValuesThrowsInvalidParameterException() {
	        try {
	            DataUtilities.getCumulativePercentages(null);
	            fail("Expected an InvalidParameterException to be thrown");
	        } catch (InvalidParameterException e) {
	            assertTrue("Expected InvalidParameterException", true);
	        }
	    }

//	 
	 
}

